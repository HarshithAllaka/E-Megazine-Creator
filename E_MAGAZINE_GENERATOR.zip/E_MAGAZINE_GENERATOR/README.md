# Magazine Maker
E-Magazine Maker provides graphical UI for creating and generating magazines.<br> It is an application that simplifies the  task of creating magazine.
<br>
Building a great magazine without the proper tools can be time-consuming and overall a difficult process.<br> Magazine Maker will save you the hassle and let you focus on what’s really important, your content.
<br>
<br>
### Requirements: 
* NetBeans IDE   (or) <br>
* Eclipse IDE with Windows Builder pluggin<br>
##### Run the file with Start.java as main class
